<?php
    // Translate Types //
    $tl_refer_visitor = get_option('translate_refer_visitor');
    $tl_refer_signup = get_option('translate_refer_signup');

    $tl_new_register = get_option('translate_new_register');
    $tl_daily_login = get_option('translate_daily_login');

    $tl_publish_post = get_option('translate_publish_post');
    $tl_approved_comment = get_option('translate_approved_comment');

    $tl_custom_post = get_option('translate_custom_post');

    $tl_woocommerce_order = get_option('translate_woocommerce_order');

    $tl_commission = get_option('translate_commission');

    $tl_points_give = get_option('translate_points_give');
    $tl_points_deduct = get_option('translate_points_deduct');
    $tl_points_added = get_option('translate_points_added');
    $tl_points_removed = get_option('translate_points_removed');

    $tl_points_transferred = get_option('translate_points_transferred');
    $tl_points_received = get_option('translate_points_received');
?>